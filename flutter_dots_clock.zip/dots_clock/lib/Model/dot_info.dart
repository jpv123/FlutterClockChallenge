import 'package:flutter/material.dart';

class DotInfo {
    int column;
    int numberIndex;
    int row;

    DotInfo({ @required this.column, @required this.numberIndex, @required this.row });
}